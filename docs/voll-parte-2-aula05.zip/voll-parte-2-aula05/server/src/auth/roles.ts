export enum Role {
  guest = "GUEST",
  paciente = "PACIENTE",
  especialista = "ESPECIALISTA",
  clinica = "CLINICA",
}
