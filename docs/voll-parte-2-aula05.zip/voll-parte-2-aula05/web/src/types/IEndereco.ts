export default interface IEndereco {
    cep: string,
    rua: string,
    numero: string,
    complemento: string,
    estado: string
}