declare module "*.module.css";
declare module "*.module.scss";
declare module "*.jpg";
declare module "*.png";