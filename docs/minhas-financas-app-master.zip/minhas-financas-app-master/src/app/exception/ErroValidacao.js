function ErroValidacao(mensagens){
    this.mensagens = mensagens;
}

export default ErroValidacao;