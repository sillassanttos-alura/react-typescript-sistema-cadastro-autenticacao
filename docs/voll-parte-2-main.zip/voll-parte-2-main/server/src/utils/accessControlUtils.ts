// import { AccessControl } from 'accesscontrol'
// const controle = new AccessControl()

// controle.grant('paciente').readAny('paciente', ['id'])

// export { controle}
