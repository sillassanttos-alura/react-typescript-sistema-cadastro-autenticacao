export default interface IProfissional {
    id: number,
    imagem: string,
    nome: string,
    especialidade: string,
    nota: number
}